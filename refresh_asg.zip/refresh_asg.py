import boto3

def lambda_handler(event, context):
    asg_name = 'terraform-20241007072147466500000005'  # Replace with your ASG name
    client = boto3.client('autoscaling')

    # Describe the Auto Scaling Group to get current instances
    response = client.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])
    instances = response['AutoScalingGroups'][0]['Instances']

    # Terminate instances
    instance_ids = [instance['InstanceId'] for instance in instances]
    
    if instance_ids:
        print(f'Terminating instances: {instance_ids}')
        client.terminate_instance_in_auto_scaling_group(
            InstanceId=instance_ids,
            ShouldDecrementDesiredCapacity=True
        )
    else:
        print('No instances to terminate.')

    return {
        'statusCode': 200,
        'body': f'Terminated instances: {instance_ids}'
    }

